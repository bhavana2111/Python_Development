# EDA INTEGRAION USING LLM FRAMEWORK USING
- OLLAMA || - MISTRAL AI || - GRADIO UI

  # Understanding meaning of each column:Data Dictionary: Variable Description

- Survived - Survived (1) or died (0)
- Pclass - Passenger’s class (1 = 1st, 2 = 2nd, 3 = 3rd)
- Name - Passenger’s name
- Sex - Passenger’s sex
- Age - Passenger’s age
- SibSp - Number of siblings/spouses aboard
- Parch - Number of parents/children aboard (Some children travelled only with a nanny, therefore parch=0 for them.)
- Ticket - Ticket number
- Fare - Fare
- Cabin - Cabin
- Embarked - Port of embarkation (C = Cherbourg, Q = Queenstown, S = Southampton)



![image Alt](https://github.com/kodigitaccount/EDA_INTEGRATION_LLM/blob/124717db0acf3b14302ae07d7e461829a2683bc9/WhatsApp%20Image%202025-02-27%20at%207.08.13%20PM.jpeg)

